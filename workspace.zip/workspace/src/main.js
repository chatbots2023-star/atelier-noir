import './styles.css'

const session = await fetch('/api/session').then((r) => r.json()).catch(() => ({ ok: false }))
if (!session.ok) {
  window.location.replace('/')
}

const PHOTOS = [
  { src: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=1200&q=80', title: 'Studio Carmim', tag: 'studio' },
  { src: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1200&q=80', title: 'Alfaiataria', tag: 'studio' },
  { src: 'https://images.unsplash.com/photo-1469334031218-e382a71b716b?auto=format&fit=crop&w=1200&q=80', title: 'Passarela', tag: 'rua' },
  { src: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?auto=format&fit=crop&w=1200&q=80', title: 'Close vermelho', tag: 'close' },
  { src: 'https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?auto=format&fit=crop&w=1200&q=80', title: 'Luz de janela', tag: 'studio' },
  { src: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=1200&q=80', title: 'Retrato suave', tag: 'close' },
  { src: 'https://images.unsplash.com/photo-1502823403499-6ccfcf4fb453?auto=format&fit=crop&w=1200&q=80', title: 'Perfil', tag: 'close' },
  { src: 'https://images.unsplash.com/photo-1521577352947-9bb58764b69a?auto=format&fit=crop&w=1200&q=80', title: 'Noite urbana', tag: 'rua' },
  { src: 'https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?auto=format&fit=crop&w=1200&q=80', title: 'Casaco preto', tag: 'studio' },
  { src: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1200&q=80', title: 'Olhar direto', tag: 'close' },
  { src: 'https://images.unsplash.com/photo-1500917293891-ef795e70e1f6?auto=format&fit=crop&w=1200&q=80', title: 'Editorial street', tag: 'rua' },
  { src: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=1200&q=80', title: 'Sombra vermelha', tag: 'studio' },
  { src: 'https://images.unsplash.com/photo-1492106087820-71f1a00d2b11?auto=format&fit=crop&w=1200&q=80', title: 'Cabelo longo', tag: 'close' },
  { src: 'https://images.unsplash.com/photo-1524502397800-2eeaad7c3fe5?auto=format&fit=crop&w=1200&q=80', title: 'Movimento', tag: 'rua' },
  { src: 'https://images.unsplash.com/photo-1479936343636-73cdc5aae0c3?auto=format&fit=crop&w=1200&q=80', title: 'Tweed', tag: 'studio' },
  { src: 'https://images.unsplash.com/photo-1504703395958-9c9dcb892237?auto=format&fit=crop&w=1200&q=80', title: 'Contraste', tag: 'studio' },
  { src: 'https://images.unsplash.com/photo-1496440737103-cd596325d76a?auto=format&fit=crop&w=1200&q=80', title: 'Calçada', tag: 'rua' },
  { src: 'https://images.unsplash.com/photo-1516726817505-f5ed825624d8?auto=format&fit=crop&w=1200&q=80', title: 'Chapéu', tag: 'close' },
  { src: 'https://images.unsplash.com/photo-1487412912498-0447578fcca8?auto=format&fit=crop&w=1200&q=80', title: 'Makeup editorial', tag: 'close' },
  { src: 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=1200&q=80', title: 'Look final', tag: 'studio' }
]

const grid = document.getElementById('grid')
const filters = document.getElementById('filters')
const lightbox = document.getElementById('lightbox')
const lbImg = document.getElementById('lbImg')
const lbCap = document.getElementById('lbCap')
let filter = 'all'
let slide = 0

function persist() {
  const custom = PHOTOS.filter((p) => p.custom)
  localStorage.setItem('atelier-photos', JSON.stringify(custom))
}

function loadCustom() {
  try {
    const extra = JSON.parse(localStorage.getItem('atelier-photos') || '[]')
    extra.forEach((p) => {
      if (p?.src) PHOTOS.push({ ...p, custom: true })
    })
  } catch {
    /* ignore */
  }
}

function renderGrid() {
  const list = PHOTOS.filter((p) => filter === 'all' || p.tag === filter)
  grid.innerHTML = list
    .map(
      (p) => `
      <article class="card" data-i="${PHOTOS.indexOf(p)}">
        <img src="${p.src}" alt="${p.title}" loading="lazy" />
        <span>${p.title}</span>
      </article>`
    )
    .join('')
}

function showSlide() {
  const p = PHOTOS[slide]
  document.getElementById('slideImg').src = p.src
  document.getElementById('slideImg').alt = p.title
  document.getElementById('slideTitle').textContent = p.title
  document.getElementById('slideTag').textContent = p.tag
  document.getElementById('slideLabel').textContent = `${slide + 1} / ${PHOTOS.length}`
}

filters.addEventListener('click', (e) => {
  const btn = e.target.closest('button')
  if (!btn) return
  filter = btn.dataset.filter
  filters.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b === btn))
  renderGrid()
})

grid.addEventListener('click', (e) => {
  const card = e.target.closest('.card')
  if (!card) return
  const p = PHOTOS[Number(card.dataset.i)]
  lbImg.src = p.src
  lbImg.alt = p.title
  lbCap.textContent = p.title
  lightbox.showModal()
})

document.getElementById('closeLb').onclick = () => lightbox.close()
lightbox.addEventListener('click', (e) => {
  if (e.target === lightbox) lightbox.close()
})

document.getElementById('prev').onclick = () => {
  slide = (slide + PHOTOS.length - 1) % PHOTOS.length
  showSlide()
}
document.getElementById('next').onclick = () => {
  slide = (slide + 1) % PHOTOS.length
  showSlide()
}

document.getElementById('navToggle').onclick = () => {
  document.querySelector('.nav').classList.toggle('open')
}

const wall = document.getElementById('wall')
const saved = JSON.parse(localStorage.getItem('atelier-wall') || '[]')
function drawWall() {
  wall.innerHTML = saved
    .slice()
    .reverse()
    .map((m) => `<li><strong>${m.name}</strong>${m.text}</li>`)
    .join('')
}
drawWall()

document.getElementById('guestForm').addEventListener('submit', (e) => {
  e.preventDefault()
  saved.push({
    name: document.getElementById('guestName').value.trim(),
    text: document.getElementById('guestMsg').value.trim()
  })
  localStorage.setItem('atelier-wall', JSON.stringify(saved))
  e.target.reset()
  drawWall()
})

loadCustom()

document.getElementById('photoUpload').addEventListener('change', (e) => {
  const files = [...(e.target.files || [])]
  if (!files.length) return
  const status = document.getElementById('uploadStatus')
  status.textContent = `Carregando ${files.length} foto(s)...`
  files.forEach((file, i) => {
    const reader = new FileReader()
    reader.onload = () => {
      PHOTOS.unshift({
        src: reader.result,
        title: file.name.replace(/\.[^.]+$/, '') || `Look ${PHOTOS.length + 1}`,
        tag: 'studio',
        custom: true
      })
      persist()
      renderGrid()
      showSlide()
      if (i === files.length - 1) {
        status.textContent = `${files.length} foto(s) adicionadas à galeria e ao carrossel.`
      }
    }
    reader.readAsDataURL(file)
  })
  e.target.value = ''
})

renderGrid()
showSlide()
