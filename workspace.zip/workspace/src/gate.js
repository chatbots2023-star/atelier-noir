import './styles.css'

const pixKey = document.getElementById('pixKey')
const qrImg = document.getElementById('qrImg')
const pixLoad = document.getElementById('pixLoad')
const pixStatus = document.getElementById('pixStatus')
const checkPay = document.getElementById('checkPay')
const waitLine = document.getElementById('waitLine')
let chargeId = sessionStorage.getItem('atelier-charge') || ''

function goBook() {
  window.location.href = '/book.html'
}

async function sessionOk() {
  const r = await fetch('/api/session')
  const data = await r.json()
  return Boolean(data.ok)
}

function fallbackQr(emv) {
  return `https://api.qrserver.com/v1/create-qr-code/?size=280x280&ecc=M&margin=8&data=${encodeURIComponent(emv)}`
}

function showQr(payload) {
  chargeId = payload.id
  sessionStorage.setItem('atelier-charge', chargeId)
  pixKey.value = payload.qr || ''
  const emv = payload.qr || ''
  qrImg.removeAttribute('hidden')
  qrImg.classList.add('on')
  qrImg.alt = 'QR Code Pix'
  qrImg.onerror = () => {
    if (emv) qrImg.src = fallbackQr(emv)
  }
  qrImg.src = payload.qrUrl || fallbackQr(emv)
  pixLoad.textContent = 'Escaneie o QR ou copie o Pix.'
}

async function createPix() {
  pixLoad.textContent = 'Gerando QR Code...'
  const r = await fetch('/api/pix/create', { method: 'POST' })
  const data = await r.json()
  if (!r.ok) {
    pixLoad.textContent = data.error || 'Não foi possível gerar o Pix agora.'
    return
  }
  showQr(data)
}

async function checkStatus(manual) {
  if (!chargeId) {
    pixStatus.textContent = 'Aguarde o QR ser gerado.'
    return
  }
  pixStatus.textContent = manual ? 'Conferindo pagamento...' : ''
  const r = await fetch(`/api/pix/status/${chargeId}`)
  const data = await r.json()
  if (data.paid) {
    pixStatus.textContent = 'Pix confirmado. Abrindo o book...'
    goBook()
    return
  }
  if (data.wait) {
    waitLine.textContent = `Ainda não pago. Nova conferência em ${data.wait}s.`
  } else {
    waitLine.textContent = 'Ainda aguardando o Pix. A alegria vem na próxima página.'
  }
  pixStatus.textContent = data.error || (manual ? 'Pagamento ainda não confirmado.' : '')
}

document.getElementById('copyPix').onclick = async () => {
  const key = pixKey.value.trim()
  if (!key) return
  try {
    await navigator.clipboard.writeText(key)
    pixStatus.textContent = 'Código copiado. Cole no app do banco.'
  } catch {
    pixKey.select()
    pixStatus.textContent = 'Código selecionado. Copie e cole no banco.'
  }
}

checkPay.onclick = () => checkStatus(true)

document.getElementById('giftForm').addEventListener('submit', (e) => {
  e.preventDefault()
  const name = document.getElementById('giftName').value.trim()
  const email = document.getElementById('giftEmail').value.trim()
  const list = JSON.parse(localStorage.getItem('atelier-gifts') || '[]')
  list.push({ name, email, at: Date.now() })
  localStorage.setItem('atelier-gifts', JSON.stringify(list))
  document.getElementById('giftStatus').textContent =
    `Obrigado, ${name}! Vou te chamar pelo nome e enviar os presentes em ${email}. Lindão.`
  e.target.reset()
})

;(async () => {
  if (await sessionOk()) {
    goBook()
    return
  }
  if (chargeId) {
    const r = await fetch(`/api/pix/status/${chargeId}`)
    const data = await r.json()
    if (data.paid) {
      goBook()
      return
    }
  }
  await createPix()
  setInterval(() => checkStatus(false), 65_000)
})()
