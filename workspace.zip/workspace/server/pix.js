import crypto from 'crypto'

const API = 'https://api.pushinpay.com.br'

function token() {
  return process.env.PUSHINPAY_TOKEN || ''
}

function valueCents() {
  return Number(process.env.PIX_VALUE_CENTS || 1999)
}

function secret() {
  return process.env.ACCESS_SECRET || 'atelier-noir-pass-2026'
}

const paid = new Set()
const lastCheck = new Map()
const qrPng = new Map()

function pngFromBase64(raw) {
  if (!raw || typeof raw !== 'string') return null
  const b64 = raw.includes(',') ? raw.slice(raw.indexOf(',') + 1) : raw
  try {
    return Buffer.from(b64, 'base64')
  } catch {
    return null
  }
}

function sign(id) {
  return crypto.createHmac('sha256', secret()).update(id).digest('hex')
}

function setAccessCookie(res, id) {
  const cookie = `${id}.${sign(id)}`
  res.setHeader(
    'Set-Cookie',
    `atelier_access=${cookie}; Path=/; HttpOnly; SameSite=Lax; Max-Age=86400`
  )
}

function readAccess(req) {
  const header = req.headers.cookie || ''
  const raw = header
    .split(';')
    .map((s) => s.trim())
    .find((s) => s.startsWith('atelier_access='))
  if (!raw) return null
  const val = decodeURIComponent(raw.slice('atelier_access='.length))
  const dot = val.lastIndexOf('.')
  if (dot < 1) return null
  const id = val.slice(0, dot)
  const sig = val.slice(dot + 1)
  if (sign(id) !== sig) return null
  return id
}

async function readJson(req) {
  const chunks = []
  for await (const chunk of req) chunks.push(chunk)
  if (!chunks.length) return {}
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8'))
  } catch {
    return {}
  }
}

function send(res, status, body) {
  res.statusCode = status
  res.setHeader('Content-Type', 'application/json; charset=utf-8')
  res.end(JSON.stringify(body))
}

async function createCharge() {
  const r = await fetch(`${API}/api/pix/cashIn`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token()}`,
      Accept: 'application/json',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      value: valueCents(),
      description: 'Apoio Atelier Noir'
    })
  })
  const data = await r.json().catch(() => ({}))
  return { ok: r.ok, status: r.status, data }
}

async function getTransaction(id) {
  const r = await fetch(`${API}/api/transactions/${id}`, {
    headers: {
      Authorization: `Bearer ${token()}`,
      Accept: 'application/json'
    }
  })
  const data = await r.json().catch(() => ({}))
  return { ok: r.ok, status: r.status, data }
}

export function pixMiddleware(req, res, next) {
  const url = req.url.split('?')[0]

  if (req.method === 'POST' && url === '/api/pix/create') {
    createCharge()
      .then(({ ok, status, data }) => {
        if (!ok) {
          send(res, status, {
            error: data.error || data.message || 'Falha ao gerar o Pix. Confira o token e o IP no painel PushinPay.'
          })
          return
        }
        const buf = pngFromBase64(data.qr_code_base64)
        if (buf && data.id) qrPng.set(data.id, buf)
        send(res, 200, {
          id: data.id,
          qr: data.qr_code,
          qrUrl: data.id ? `/api/pix/qr/${data.id}` : '',
          value: data.value,
          status: data.status
        })
      })
      .catch((err) => send(res, 500, { error: err.message }))
    return
  }

  if (req.method === 'GET' && url.startsWith('/api/pix/qr/')) {
    const id = url.replace('/api/pix/qr/', '').replace(/\/$/, '')
    const buf = qrPng.get(id)
    if (!buf) {
      res.statusCode = 404
      res.end()
      return
    }
    res.statusCode = 200
    res.setHeader('Content-Type', 'image/png')
    res.setHeader('Cache-Control', 'no-store')
    res.end(buf)
    return
  }

  if (req.method === 'GET' && url.startsWith('/api/pix/status/')) {
    const id = url.replace('/api/pix/status/', '').replace(/\/$/, '')
    if (!id) {
      send(res, 400, { error: 'id ausente' })
      return
    }
    if (paid.has(id)) {
      setAccessCookie(res, id)
      send(res, 200, { status: 'paid', paid: true })
      return
    }
    const now = Date.now()
    const prev = lastCheck.get(id) || 0
    const wait = Math.ceil((60_000 - (now - prev)) / 1000)
    if (prev && wait > 0) {
      send(res, 200, { status: 'created', paid: false, wait })
      return
    }
    lastCheck.set(id, now)
    getTransaction(id)
      .then(({ data }) => {
        const status = data.status || 'created'
        if (status === 'paid') {
          paid.add(id)
          setAccessCookie(res, id)
        }
        send(res, 200, { status, paid: status === 'paid' })
      })
      .catch((err) => send(res, 500, { error: err.message }))
    return
  }

  if (req.method === 'POST' && url === '/api/pix/webhook') {
    readJson(req).then((body) => {
      if (body?.status === 'paid' && body.id) paid.add(body.id)
      send(res, 200, { ok: true })
    })
    return
  }

  if (req.method === 'GET' && url === '/api/session') {
    const id = readAccess(req)
    send(res, 200, { ok: Boolean(id) })
    return
  }

  if (req.method === 'GET' && (url === '/book.html' || url === '/book')) {
    if (!readAccess(req)) {
      res.statusCode = 302
      res.setHeader('Location', '/')
      res.end()
      return
    }
  }

  next()
}
