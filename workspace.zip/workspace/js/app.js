const TELEGRAM_URL = "https://t.me/dannyyof";
const checkout = document.getElementById("checkout");
const stepPay = document.getElementById("stepPay");
const stepOk = document.getElementById("stepOk");
const planName = document.getElementById("planName");
const planPrice = document.getElementById("planPrice");
const pixCode = document.getElementById("pixCode");
const countEl = document.getElementById("count");
const qrImg = document.getElementById("qrImg");
const qrPlaceholder = document.getElementById("qrPlaceholder");
const payError = document.getElementById("payError");
const confirmPay = document.getElementById("confirmPay");
const waitMsg = document.getElementById("waitMsg");

let currentId = null;
let pollTimer = null;
let redirectTimer = null;

function showError(message) {
  payError.hidden = !message;
  payError.textContent = message || "";
}

function showQr(src) {
  qrImg.src = src;
  qrImg.hidden = false;
  qrPlaceholder.hidden = true;
}

function resetPayUi() {
  currentId = null;
  pixCode.value = "";
  qrImg.hidden = true;
  qrImg.removeAttribute("src");
  qrPlaceholder.hidden = false;
  qrPlaceholder.textContent = "Gerando PIX...";
  confirmPay.hidden = true;
  waitMsg.textContent = "Aguardando confirmacao do PIX...";
  showError("");
  clearInterval(pollTimer);
  clearInterval(redirectTimer);
}

function goTelegramSoon() {
  let n = 5;
  countEl.textContent = String(n);
  clearInterval(redirectTimer);
  redirectTimer = setInterval(() => {
    n -= 1;
    countEl.textContent = String(n);
    if (n <= 0) {
      clearInterval(redirectTimer);
      window.location.href = TELEGRAM_URL;
    }
  }, 1000);
}

function markPaid() {
  clearInterval(pollTimer);
  stepPay.hidden = true;
  stepOk.hidden = false;
  goTelegramSoon();
}

async function checkStatus(force) {
  if (!currentId) return;
  const url = force ? "/api/status" : "/api/status?id=" + encodeURIComponent(currentId);
  const options = force
    ? {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: currentId }),
      }
    : { method: "GET" };
  const res = await fetch(url, options);
  const data = await res.json();
  if (data.paid || data.status === "paid") markPaid();
}

function startPolling() {
  clearInterval(pollTimer);
  pollTimer = setInterval(() => {
    checkStatus(false).catch(() => {});
  }, 65000);
}

function fallbackQr(code) {
  return "https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=" + encodeURIComponent(code);
}

async function openCheckout(plan) {
  resetPayUi();
  stepPay.hidden = false;
  stepOk.hidden = true;
  checkout.hidden = false;

  try {
    const res = await fetch("/api/pix", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ plan }),
    });
    const data = await res.json();
    if (!data.ok) {
      qrPlaceholder.textContent = "PIX indisponivel";
      showError(data.error || "Nao foi possivel gerar o PIX.");
      return;
    }
    currentId = data.id;
    planName.textContent = data.label;
    planPrice.textContent = data.price;
    pixCode.value = data.qr_code || "";
    if (data.qr_url) {
      showQr(data.qr_url);
    } else if (data.qr_image) {
      showQr(data.qr_image);
    } else if (data.qr_code) {
      showQr(fallbackQr(data.qr_code));
    } else {
      qrPlaceholder.textContent = "Use o codigo copia e cola";
    }
    qrImg.onerror = function () {
      if (data.qr_code) showQr(fallbackQr(data.qr_code));
    };
    confirmPay.hidden = false;
    startPolling();
  } catch (err) {
    qrPlaceholder.textContent = "PIX indisponivel";
    showError("Falha de conexao ao gerar o PIX.");
  }
}

document.querySelectorAll(".plan button").forEach((btn) => {
  btn.addEventListener("click", () => openCheckout(btn.dataset.plan));
});

document.getElementById("closeCheckout").addEventListener("click", () => {
  checkout.hidden = true;
  clearInterval(pollTimer);
});

checkout.addEventListener("click", (e) => {
  if (e.target === checkout) {
    checkout.hidden = true;
    clearInterval(pollTimer);
  }
});

document.getElementById("copyPix").addEventListener("click", async () => {
  if (!pixCode.value) return;
  try {
    await navigator.clipboard.writeText(pixCode.value);
    document.getElementById("copyPix").textContent = "Copiado";
    setTimeout(() => {
      document.getElementById("copyPix").textContent = "Copiar";
    }, 1400);
  } catch {
    pixCode.select();
  }
});

confirmPay.addEventListener("click", async () => {
  confirmPay.disabled = true;
  waitMsg.textContent = "Confirmando pagamento...";
  try {
    await checkStatus(true);
    if (stepOk.hidden) waitMsg.textContent = "Ainda nao recebemos o PIX. Aguarde alguns segundos e tente de novo.";
  } catch {
    waitMsg.textContent = "Nao foi possivel consultar o pagamento agora.";
  }
  confirmPay.disabled = false;
});
